<section class="content content-header ">
  <div class="error-page">
    <h2 class="headline text-warning"> 500</h2>

    <div class="error-content">
      <h3><i class="fas fa-exclamation-triangle text-warning"></i> Oops! No Permission</h3>

      <p>
        Anda tidak memiliki izin untuk mengakses file ini.<br>
        Silahkan <a href="#">Logout</a>, atau hubungi Admin.
      </p>

    </div>
    <!-- /.error-content -->
  </div>
  <!-- /.error-page -->
</section>